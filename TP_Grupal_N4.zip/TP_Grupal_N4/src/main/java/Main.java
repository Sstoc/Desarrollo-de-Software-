import DTOs.UsuarioDTO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Categoria catElectronica = Categoria.builder()
                .id(1L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Electronica")
                .descripcion("Dispositivos electronicos y tecnologia")
                .build();

        Categoria catRopa = Categoria.builder()
                .id(2L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Ropa")
                .descripcion("Indumentaria y calzado")
                .build();

        Categoria catHogar = Categoria.builder()
                .id(3L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Hogar")
                .descripcion("Articulos para el hogar y muebles")
                .build();

        Producto p1 = Producto.builder()
                .id(1L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Smartphone")
                .precio(800.0)
                .descripcion("Telefono inteligente")
                .stock(25)
                .imagen("smartphone.png")
                .disponible(true)
                .build();

        Producto p2 = Producto.builder()
                .id(2L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Notebook")
                .precio(1200.0)
                .descripcion("Computadora portatil")
                .stock(15)
                .imagen("notebook.png")
                .disponible(true)
                .build();

        Producto p3 = Producto.builder()
                .id(3L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Auriculares")
                .precio(150.0)
                .descripcion("Auriculares inalambricos")
                .stock(40)
                .imagen("auriculares.png")
                .disponible(true)
                .build();

        Producto p4 = Producto.builder()
                .id(4L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Smartwatch")
                .precio(250.0)
                .descripcion("Reloj inteligente")
                .stock(30)
                .imagen("smartwatch.png")
                .disponible(true)
                .build();

        Producto p5 = Producto.builder()
                .id(5L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Camiseta")
                .precio(35.0)
                .descripcion("Camiseta deportiva")
                .stock(60)
                .imagen("camiseta.png")
                .disponible(true)
                .build();

        Producto p6 = Producto.builder()
                .id(6L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Pantalon")
                .precio(55.0)
                .descripcion("Pantalon clasico")
                .stock(50)
                .imagen("pantalon.png")
                .disponible(true)
                .build();

        Producto p7 = Producto.builder()
                .id(7L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Zapatillas")
                .precio(90.0)
                .descripcion("Calzado deportivo")
                .stock(35)
                .imagen("zapatillas.png")
                .disponible(true)
                .build();

        Producto p8 = Producto.builder()
                .id(8L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Cafetera")
                .precio(180.0)
                .descripcion("Cafetera automatica")
                .stock(20)
                .imagen("cafetera.png")
                .disponible(true)
                .build();

        Producto p9 = Producto.builder()
                .id(9L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Lampara")
                .precio(45.0)
                .descripcion("Lampara de escritorio")
                .stock(40)
                .imagen("lampara.png")
                .disponible(true)
                .build();

        Producto p10 = Producto.builder()
                .id(10L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Aspiradora")
                .precio(320.0)
                .descripcion("Aspiradora robot")
                .stock(18)
                .imagen("aspiradora.png")
                .disponible(true)
                .build();

        catElectronica.getProductos().addAll(List.of(p1, p2, p3, p4));
        catRopa.getProductos().addAll(List.of(p5, p6, p7));
        catHogar.getProductos().addAll(List.of(p8, p9, p10));

        List<Producto> productos = new ArrayList<>(List.of(p1, p2, p3, p4, p5, p6, p7, p8, p9, p10));

        DetallePedido dp1_1 = DetallePedido.builder()
                .id(1L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(1)
                .producto(p1)
                .subtotal(p1.getPrecio() * 1)
                .build();

        DetallePedido dp1_2 = DetallePedido.builder()
                .id(2L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(2)
                .producto(p3)
                .subtotal(p3.getPrecio() * 2)
                .build();

        Pedido pedido1 = Pedido.builder()
                .id(1L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .fecha(LocalDate.now())
                .estado(Estado.CONFIRMADO)
                .formaPago(FormaPago.TARJETA)
                .detalles(new ArrayList<>(List.of(dp1_1, dp1_2)))
                .build();
        pedido1.calcularTotal();

        DetallePedido dp2_1 = DetallePedido.builder()
                .id(3L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(1)
                .producto(p2)
                .subtotal(p2.getPrecio() * 1)
                .build();

        DetallePedido dp2_2 = DetallePedido.builder()
                .id(4L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(1)
                .producto(p8)
                .subtotal(p8.getPrecio() * 1)
                .build();

        Pedido pedido2 = Pedido.builder()
                .id(2L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .fecha(LocalDate.now())
                .estado(Estado.PENDIENTE)
                .formaPago(FormaPago.TRANSFERENCIA)
                .detalles(new ArrayList<>(List.of(dp2_1, dp2_2)))
                .build();
        pedido2.calcularTotal();

        DetallePedido dp3_1 = DetallePedido.builder()
                .id(5L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(2)
                .producto(p5)
                .subtotal(p5.getPrecio() * 2)
                .build();

        DetallePedido dp3_2 = DetallePedido.builder()
                .id(6L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .cantidad(1)
                .producto(p6)
                .subtotal(p6.getPrecio() * 1)
                .build();

        Pedido pedido3 = Pedido.builder()
                .id(3L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .fecha(LocalDate.now())
                .estado(Estado.TERMINADO)
                .formaPago(FormaPago.EFECTIVO)
                .detalles(new ArrayList<>(List.of(dp3_1, dp3_2)))
                .build();
        pedido3.calcularTotal();

        Usuario usuario1 = Usuario.builder()
                .id(1L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Juan")
                .apellido("Perez")
                .mail("juan.perez@example.com")
                .celular("1122334455")
                .contraseña("clave123")
                .rol(Rol.ADMIN)
                .pedidos(new ArrayList<>(List.of(pedido1, pedido2)))
                .build();

        Usuario usuario2 = Usuario.builder()
                .id(2L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre("Maria")
                .apellido("Gomez")
                .mail("maria.gomez@example.com")
                .celular("1199887766")
                .contraseña("segura456")
                .rol(Rol.USUARIO)
                .pedidos(new ArrayList<>(List.of(pedido3)))
                .build();

        System.out.println(p1.toString());

        for (Producto p : productos) {
            System.out.println(p.toString());
        }

        List<Usuario> usuarios = List.of(usuario1, usuario2);
        Usuario usuarioConMasPedidos = usuarios.get(0);
        for (Usuario u : usuarios) {
            if (u.getPedidos().size() > usuarioConMasPedidos.getPedidos().size()) {
                usuarioConMasPedidos = u;
            }
        }
        for (Pedido p : usuarioConMasPedidos.getPedidos()) {
            System.out.println(p.toString());
        }

        Producto nuevoProducto = Producto.builder()
                .id(99L)
                .eliminado(false)
                .createdAt(LocalDateTime.now())
                .nombre(p1.getNombre())
                .precio(9999.0)
                .descripcion("Producto de prueba para equals")
                .stock(0)
                .imagen("prueba.png")
                .disponible(false)
                .build();

        for (Producto p : productos) {
            System.out.println(nuevoProducto.equals(p));
        }

        UsuarioDTO usuarioDTO = usuario1.toDTO();
        System.out.println(usuarioDTO.toString());
    }
}
