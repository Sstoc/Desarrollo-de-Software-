public interface Calculable {
    void calcularTotal();
}
