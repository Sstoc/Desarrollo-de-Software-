import DTOs.UsuarioDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Usuario extends Base {
    private String nombre;
    private String apellido;
    private String mail;
    private String celular;
    private String contraseña;
    private Rol rol;

    @Builder.Default
    private List<Pedido> pedidos = new ArrayList<>();

    public UsuarioDTO toDTO() {
        return new UsuarioDTO(getId(), isEliminado(), getCreatedAt(), nombre, apellido, mail, celular);
    }
}
