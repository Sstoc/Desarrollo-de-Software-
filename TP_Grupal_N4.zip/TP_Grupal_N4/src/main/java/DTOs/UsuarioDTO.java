package DTOs;

import java.time.LocalDateTime;

public record UsuarioDTO(
    Long id,
    boolean eliminado,
    LocalDateTime createdAt,
    String nombre,
    String apellido,
    String mail,
    String celular
) {
    public UsuarioDTO(Long id, String nombre, String apellido, String mail, String celular) {
        this(id, false, null, nombre, apellido, mail, celular);
    }

    public UsuarioDTO(String nombre, String apellido, String mail, String celular) {
        this(null, false, null, nombre, apellido, mail, celular);
    }
}
