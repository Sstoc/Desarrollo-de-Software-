import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DetallePedido extends Base {
    private int cantidad;
    private Double subtotal;
    private Producto producto;

    public Double getSubtotal() {
        if (subtotal == null && producto != null && producto.getPrecio() != null) {
            return producto.getPrecio() * cantidad;
        }
        return subtotal;
    }
}
