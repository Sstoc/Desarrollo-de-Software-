import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@ToString
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class Pedido extends Base implements Calculable {
    private LocalDate fecha;
    private Estado estado;
    private Double total;
    private FormaPago formaPago;

    @Builder.Default
    private List<DetallePedido> detalles = new ArrayList<>();

    public void addDetallePedido(int cantidad, Producto producto) {
        if (detalles == null) {
            detalles = new ArrayList<>();
        }
        Double sub = (producto != null && producto.getPrecio() != null) ? producto.getPrecio() * cantidad : 0.0;
        DetallePedido detalle = DetallePedido.builder()
                .cantidad(cantidad)
                .producto(producto)
                .subtotal(sub)
                .build();
        detalles.add(detalle);
        calcularTotal();
    }

    public DetallePedido findDetallePedidoByProducto(Producto producto) {
        if (detalles == null || producto == null) {
            return null;
        }
        for (DetallePedido detalle : detalles) {
            if (producto.equals(detalle.getProducto())) {
                return detalle;
            }
        }
        return null;
    }

    public void deleteDetallePedidoByProducto(Producto producto) {
        if (detalles == null || producto == null) {
            return;
        }
        DetallePedido encontrado = findDetallePedidoByProducto(producto);
        if (encontrado != null) {
            detalles.remove(encontrado);
            calcularTotal();
        }
    }

    @Override
    public void calcularTotal() {
        double sum = 0.0;
        if (detalles != null) {
            for (DetallePedido detalle : detalles) {
                if (detalle.getSubtotal() != null) {
                    sum += detalle.getSubtotal();
                }
            }
        }
        this.total = sum;
    }
}
