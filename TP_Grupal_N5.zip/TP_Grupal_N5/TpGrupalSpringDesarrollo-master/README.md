# Trabajo Práctico: Operaciones de Escritura en API REST y Frontend CRUD en TypeScript

Este proyecto implementa de manera completa y desacoplada las operaciones de escritura (POST, PUT, DELETE) y consulta (GET, Reportes) para la gestión de Facturas de Venta, junto con su interfaz de usuario moderna desarrollada en TypeScript y HTML5.

---

## 🚀 Tecnologías Utilizadas

- **Backend:** Java 17, Spring Boot 4.x / 3.x, Spring Data JPA, Hibernate, PostgreSQL, OpenPDF (para reportes ejecutivos), JUnit 5, Mockito.
- **Frontend:** TypeScript, HTML5, Bootstrap 5, Bootstrap Icons, Fetch API con async/await y arquitectura modular (ES Modules).

---

## 📋 Cumplimiento de Consignas del Trabajo Práctico

### 1. DTOs de Entrada (Request DTOs)
- **`FacturaRequestDTO`:** Diseñado para desacoplar el contrato de la API del modelo de base de datos. Recibe identificadores primitivos (`clienteId`, `condicionIvaId`, `puntoVentaId`, `tipoMonedaId`) en lugar de entidades anidadas.
- **`FacturaDetalleRequestDTO`:** Estructura los renglones de la factura recibiendo `articuloId`, `cantidad` y opcionalmente `precioUnitario`.

### 2. Lógica de Negocio en la Capa de Servicio (`FacturaService`)
- **`@Transactional`:** Garantiza la atomicidad de las operaciones de escritura en base de datos.
- **Creación en Cascada (`crear`):**
  - Validación y búsqueda por ID de las entidades asociadas (`PuntoVenta`, `CondicionIva`, `TipoMoneda`, `Cliente`, `Articulo`). Lanza `ResourceNotFoundException` (404) si no existen.
  - Generación de numeración automática si no se suministra.
  - Cálculo automático de subtotales, totales y saldos a partir de los ítems suministrados.
  - Persistencia en cascada (`CascadeType.ALL`) de la cabecera `FacturaVenta` y sus renglones `FacturaVentaDetalle`.
- **Actualización (`actualizar`):**
  - Búsqueda por ID. Lanza 404 si el comprobante no existe.
  - Actualización dinámica de cabecera (estado, observaciones, fecha, relaciones) y regeneración de ítems.
- **Eliminación y Anulación (`eliminar` / `eliminarFisicamente`):**
  - Anulación lógica de comprobantes registrando `estado = "ANULADA"` y `fechaAnulacion = new Date()` conforme a normas comerciales y contables de facturación.
  - Método de eliminación física disponible para depuración de registros en entornos de prueba.

### 3. Capa de Controladores REST (`FacturaRestController`)
Endpoints expuestos bajo `/api/facturas`:
- `POST /api/facturas`: Recibe `FacturaRequestDTO`, crea el comprobante y retorna código **`201 Created`** con el `FacturaReporteDTO`.
- `PUT /api/facturas/{id}`: Actualiza la cabecera / estado del comprobante y retorna código **`200 OK`**.
- `DELETE /api/facturas/{id}`: Realiza la anulación/baja del comprobante y retorna código **`204 No Content`**.
- `GET /api/facturas`: Consulta con filtros dinámicos (fechas, estado, monto mínimo) vía JPQL y retorna **`200 OK`**.
- `GET /api/facturas/{id}`: Detalle por ID con manejo de **`404 Not Found`** ante inexistencia.
- `GET /api/facturas/reporte/pdf` y `GET /api/facturas/reporte/excel`: Exportación de reportes ejecutivos.

### 4, 5, 6 y 7. Frontend CRUD con TypeScript y HTML5
- **Interfaces TypeScript (`frontend/models/factura.dto.ts`):** Espejo exacto de los DTOs de Java (`FacturaRequestDTO`, `FacturaDetalleRequestDTO`, `FacturaReporteDTO`, `FacturaFiltrosDTO`).
- **Capa de Servicio HTTP (`frontend/FacturaService.ts`):** Centraliza el consumo de la API mediante `fetch` y `async/await`:
  - `obtenerFacturas(filtros?: FacturaFiltrosDTO): Promise<FacturaReporteDTO[]>`
  - `crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO>`
  - `actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO>`
  - `eliminarFactura(id: number): Promise<void>`
- **Interfaz Gráfica (`frontend/index.html` y `frontend/app.ts`):**
  - **Formulario de Alta con Tabla Dinámica:** Permite seleccionar artículos, especificar cantidades/precios y acumular renglones en memoria con cálculo en tiempo real antes del envío en lote vía POST.
  - **Filtros de Búsqueda:** Búsqueda combinada por rango de fechas, estado del comprobante y monto mínimo.
  - **Listado y Acciones por Fila:** Visualización de comprobantes registrados con botones para **Anular (PUT)** y **Eliminar (DELETE)** con confirmación interactiva.

---

## 🛠️ Cómo Ejecutar el Proyecto

### 1. Configuración de Base de Datos
Verifique que el servicio de PostgreSQL esté activo en el puerto 5432 y que exista la base de datos `ventas` con las credenciales configuradas en `TpGrupalSpringDesarrollo-master/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/ventas
spring.datasource.username=postgres
spring.datasource.password=admin
```

### 2. Ejecutar Pruebas Automatizadas
Para verificar la suite de tests unitarios y de controladores (12 pruebas ejecutadas y aprobadas):
```bash
cd TpGrupalSpringDesarrollo-master
./gradlew test
```

### 3. Iniciar el Backend
```bash
cd TpGrupalSpringDesarrollo-master
./gradlew bootRun
```
El servidor iniciará en `http://localhost:8080`.

### 4. Abrir la Interfaz de Usuario
El frontend está embebido en los recursos estáticos de Spring Boot (`src/main/resources/static`) y también disponible como aplicación web independiente en `frontend/index.html`:
- **Acceso directo vía Spring Boot:** Ingrese en el navegador a `http://localhost:8080` o `http://localhost:8080/index.html`.
- **Acceso independiente:** Abra directamente el archivo `TpGrupalSpringDesarrollo-master/frontend/index.html` (o use la extensión Live Server de VS Code).
