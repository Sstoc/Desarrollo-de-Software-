import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf;
        try {
            emf = Persistence.createEntityManagerFactory("FacturacionPU");
        } catch (Exception e) {
            emf = Persistence.createEntityManagerFactory("FacturacionTestH2PU");
        }

        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Date fechaActual = new Date();

            Usuario usuario = new Usuario("admin", "admin123", "Ignacio", "Generoso");
            em.persist(usuario);

            PuntoVenta puntoVenta = new PuntoVenta(1, "Sucursal Central", "Electronica", "Av. San Martin 1234");
            puntoVenta.setFechaAlta(fechaActual);
            puntoVenta.setFechaModificacion(fechaActual);
            puntoVenta.setUsuarioCarga(usuario);
            puntoVenta.setUsuarioModificacion(usuario);
            em.persist(puntoVenta);

            Rubro rubro = new Rubro("Hardware y Perifericos", 101);
            rubro.setFechaAlta(fechaActual);
            rubro.setFechaModificacion(fechaActual);
            rubro.setUsuarioCarga(usuario);
            rubro.setUsuarioModificacion(usuario);
            em.persist(rubro);

            Marca marca = new Marca("Logitech", 202);
            marca.setFechaAlta(fechaActual);
            marca.setFechaModificacion(fechaActual);
            marca.setUsuarioCarga(usuario);
            marca.setUsuarioModificacion(usuario);
            em.persist(marca);

            Articulo teclado = new Articulo(rubro, "ART-001", "Teclado Mecanico RGB", marca);
            teclado.setFechaAlta(fechaActual);
            teclado.setFechaModificacion(fechaActual);
            teclado.setUsuarioCarga(usuario);
            teclado.setUsuarioModificacion(usuario);
            em.persist(teclado);

            Articulo mouse = new Articulo(rubro, "ART-002", "Mouse Inalambrico Pro", marca);
            mouse.setFechaAlta(fechaActual);
            mouse.setFechaModificacion(fechaActual);
            mouse.setUsuarioCarga(usuario);
            mouse.setUsuarioModificacion(usuario);
            em.persist(mouse);

            ListaPrecio listaMayorista = new ListaPrecio("LP-MAY", "Lista Mayorista General");
            listaMayorista.setFechaAlta(fechaActual);
            listaMayorista.setFechaModificacion(fechaActual);
            listaMayorista.setUsuarioCarga(usuario);
            listaMayorista.setUsuarioModificacion(usuario);
            em.persist(listaMayorista);

            ListaPrecioArticulo lpaTeclado = new ListaPrecioArticulo(listaMayorista, 75000.0, teclado);
            lpaTeclado.setFechaAlta(fechaActual);
            lpaTeclado.setFechaModificacion(fechaActual);
            lpaTeclado.setUsuarioCarga(usuario);
            lpaTeclado.setUsuarioModificacion(usuario);
            em.persist(lpaTeclado);

            ListaPrecioArticulo lpaMouse = new ListaPrecioArticulo(listaMayorista, 45000.0, mouse);
            lpaMouse.setFechaAlta(fechaActual);
            lpaMouse.setFechaModificacion(fechaActual);
            lpaMouse.setUsuarioCarga(usuario);
            lpaMouse.setUsuarioModificacion(usuario);
            em.persist(lpaMouse);

            Contacto contacto = new Contacto("cliente@empresa.com", "42345678", "1198765432");
            Domicilio domicilio = new Domicilio("Av. Corrientes", "1234");
            Cliente cliente = new Cliente("30-12345678-9", "Empresa Distribuidora SA", contacto, domicilio);
            cliente.setFechaAlta(fechaActual);
            cliente.setFechaModificacion(fechaActual);
            cliente.setUsuarioCarga(usuario);
            cliente.setUsuarioModificacion(usuario);
            em.persist(cliente);

            FacturaVenta factura = new FacturaVenta();
            factura.setNumero(10001L);
            factura.setFechaEmision(fechaActual);
            factura.setPuntoVenta(puntoVenta);
            factura.setEstado("EMITIDA");
            factura.setCae("74281928401923");
            factura.setCaeFechaVencimiento(fechaActual);
            factura.setResultadoAfip("APROBADA");
            factura.setObservaciones("Factura de venta mayorista con persistencia en cascada");
            factura.setFechaAlta(fechaActual);
            factura.setFechaModificacion(fechaActual);
            factura.setUsuarioCarga(usuario);
            factura.setUsuarioModificacion(usuario);

            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle(
                    lpaTeclado,
                    "Teclado Mecanico RGB Switch Brown",
                    2.0,
                    75000.0,
                    0.0,
                    150000.0,
                    31500.0,
                    181500.0
            );

            FacturaVentaDetalle detalle2 = new FacturaVentaDetalle(
                    lpaMouse,
                    "Mouse Inalambrico Pro Sensor Hero",
                    4.0,
                    45000.0,
                    10.0,
                    162000.0,
                    34020.0,
                    196020.0
            );

            factura.addDetalle(detalle1);
            factura.addDetalle(detalle2);

            double total = detalle1.getImporteSubtotal() + detalle2.getImporteSubtotal();
            factura.setImporteTotal(total);
            factura.setImporteCobrado(total);
            factura.setImporteSaldo(0.0);

            em.persist(factura);

            em.getTransaction().commit();

            em.clear();

            FacturaVenta facturaRecuperada = em.find(FacturaVenta.class, factura.getId());
            if (facturaRecuperada != null) {
                System.out.println("Factura ID: " + facturaRecuperada.getId());
                System.out.println("Numero: " + facturaRecuperada.getNumero());
                System.out.println("Punto de Venta: " + facturaRecuperada.getPuntoVenta().getDescripcion());
                System.out.println("Total: " + facturaRecuperada.getImporteTotal());
                System.out.println("Cantidad de detalles: " + facturaRecuperada.getDetalles().size());

                for (FacturaVentaDetalle d : facturaRecuperada.getDetalles()) {
                    System.out.println("Detalle ID: " + d.getId() +
                            " - Descripcion: " + d.getDescripcion() +
                            " - Cantidad: " + d.getCantidad() +
                            " - Subtotal: " + d.getImporteSubtotal() +
                            " - Factura ID: " + d.getFactura().getId());
                }
            }

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
