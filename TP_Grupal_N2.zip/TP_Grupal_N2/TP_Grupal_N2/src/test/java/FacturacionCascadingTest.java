import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FacturacionCascadingTest {

    private static EntityManagerFactory emf;
    private EntityManager em;

    @BeforeAll
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("FacturacionTestH2PU");
    }

    @AfterAll
    public static void tearDownClass() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }

    @BeforeEach
    public void setUp() {
        em = emf.createEntityManager();
        em.getTransaction().begin();
    }

    @AfterEach
    public void tearDown() {
        if (em != null && em.isOpen()) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            em.close();
        }
    }

    @Test
    public void testPersistenciaFacturaConDetallesEnCascada() {
        Date fechaActual = new Date();

        Usuario usuario = new Usuario("admin", "admin123", "Ignacio", "Generoso");
        em.persist(usuario);

        PuntoVenta puntoVenta = new PuntoVenta(1, "Central", "Electronica", "Av. San Martin 1234");
        puntoVenta.setFechaAlta(fechaActual);
        puntoVenta.setFechaModificacion(fechaActual);
        puntoVenta.setUsuarioCarga(usuario);
        puntoVenta.setUsuarioModificacion(usuario);
        em.persist(puntoVenta);

        Rubro rubro = new Rubro("Perifericos", 101);
        rubro.setFechaAlta(fechaActual);
        rubro.setFechaModificacion(fechaActual);
        rubro.setUsuarioCarga(usuario);
        rubro.setUsuarioModificacion(usuario);
        em.persist(rubro);

        Marca marca = new Marca("Logitech", 202);
        marca.setFechaAlta(fechaActual);
        marca.setFechaModificacion(fechaActual);
        marca.setUsuarioCarga(usuario);
        marca.setUsuarioModificacion(usuario);
        em.persist(marca);

        Articulo articulo = new Articulo(rubro, "ART-001", "Teclado", marca);
        articulo.setFechaAlta(fechaActual);
        articulo.setFechaModificacion(fechaActual);
        articulo.setUsuarioCarga(usuario);
        articulo.setUsuarioModificacion(usuario);
        em.persist(articulo);

        ListaPrecio listaPrecio = new ListaPrecio("LP-01", "Mayorista");
        listaPrecio.setFechaAlta(fechaActual);
        listaPrecio.setFechaModificacion(fechaActual);
        listaPrecio.setUsuarioCarga(usuario);
        listaPrecio.setUsuarioModificacion(usuario);
        em.persist(listaPrecio);

        ListaPrecioArticulo lpa = new ListaPrecioArticulo(listaPrecio, 50000.0, articulo);
        lpa.setFechaAlta(fechaActual);
        lpa.setFechaModificacion(fechaActual);
        lpa.setUsuarioCarga(usuario);
        lpa.setUsuarioModificacion(usuario);
        em.persist(lpa);

        FacturaVenta factura = new FacturaVenta();
        factura.setNumero(2001L);
        factura.setFechaEmision(fechaActual);
        factura.setPuntoVenta(puntoVenta);
        factura.setEstado("EMITIDA");
        factura.setImporteTotal(50000.0);
        factura.setFechaAlta(fechaActual);
        factura.setFechaModificacion(fechaActual);
        factura.setUsuarioCarga(usuario);
        factura.setUsuarioModificacion(usuario);

        FacturaVentaDetalle detalle = new FacturaVentaDetalle(
                lpa, "Teclado Mecanico", 1.0, 50000.0, 0.0, 50000.0, 10500.0, 60500.0
        );
        factura.addDetalle(detalle);

        em.persist(factura);
        em.getTransaction().commit();

        em.clear();

        FacturaVenta recuperada = em.find(FacturaVenta.class, factura.getId());
        assertNotNull(recuperada);
        assertNotNull(recuperada.getId());
        assertEquals(1, recuperada.getDetalles().size());

        FacturaVentaDetalle detalleRecuperado = recuperada.getDetalles().get(0);
        assertNotNull(detalleRecuperado.getId());
        assertEquals("Teclado Mecanico", detalleRecuperado.getDescripcion());
        assertEquals(recuperada.getId(), detalleRecuperado.getFactura().getId());
    }

    @Test
    public void testPersistenciaClienteConContactoYDomicilio() {
        Date fechaActual = new Date();

        Usuario usuario = new Usuario("user2", "pass123", "Juan", "Perez");
        em.persist(usuario);

        Contacto contacto = new Contacto("juan@mail.com", "45678901", "1123456789");
        Domicilio domicilio = new Domicilio("San Jeronimo", "450");
        Cliente cliente = new Cliente("20-30405060-7", "Juan Perez", contacto, domicilio);
        cliente.setFechaAlta(fechaActual);
        cliente.setFechaModificacion(fechaActual);
        cliente.setUsuarioCarga(usuario);
        cliente.setUsuarioModificacion(usuario);

        em.persist(cliente);
        em.getTransaction().commit();

        em.clear();

        Cliente clienteRecuperado = em.find(Cliente.class, cliente.getId());
        assertNotNull(clienteRecuperado);
        assertNotNull(clienteRecuperado.getId());
        assertNotNull(clienteRecuperado.getContacto());
        assertNotNull(clienteRecuperado.getDomicilio());
        assertEquals("juan@mail.com", clienteRecuperado.getContacto().getEmail());
        assertEquals("San Jeronimo", clienteRecuperado.getDomicilio().getNombreCalle());
    }

    @Test
    public void testEntityIdEqualsAndHashCode() {
        Usuario u1 = new Usuario();
        u1.setId(10L);

        Usuario u2 = new Usuario();
        u2.setId(10L);

        Usuario u3 = new Usuario();
        u3.setId(20L);

        assertEquals(u1, u2);
        assertTrue(!u1.equals(u3));
        assertEquals(u1.hashCode(), u2.hashCode());
    }
}
