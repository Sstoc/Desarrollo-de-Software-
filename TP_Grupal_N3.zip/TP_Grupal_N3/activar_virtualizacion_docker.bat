@echo off
:: Solicitar permisos de administrador si no los tiene
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permisos de administrador...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ===========================================================
echo   ACTIVANDO CARACTERISTICAS DE VIRTUALIZACION PARA DOCKER
echo ===========================================================
echo.
echo 1. Habilitando Plataforma de Maquina Virtual...
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart

echo.
echo 2. Habilitando Subsistema de Windows para Linux (WSL)...
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart

echo.
echo 3. Configurando inicio automatico del hipervisor...
bcdedit /set hypervisorlaunchtype auto

echo.
echo ===========================================================
echo   PROCESO COMPLETADO EXITOSAMENTE
echo   Por favor, REINICIA TU COMPUTADORA ahora para aplicar
echo   los cambios y que Docker Desktop funcione.
echo ===========================================================
pause
