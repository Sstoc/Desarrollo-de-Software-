import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.Date;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf;
        try {
            emf = Persistence.createEntityManagerFactory("FacturacionPU");
            System.out.println(">>> Conectado exitosamente a PostgreSQL (FacturacionPU) <<<");
        } catch (Exception e) {
            System.out.println(">>> Fallo conexion a PostgreSQL, usando fallback H2 en memoria <<<");
            emf = Persistence.createEntityManagerFactory("FacturacionTestH2PU");
        }

        EntityManager em = emf.createEntityManager();

        try {
            // Verificar si ya existen facturas en la base de datos
            List<FacturaVenta> facturasExistentes = em.createQuery("SELECT f FROM FacturaVenta f", FacturaVenta.class)
                    .getResultList();

            if (facturasExistentes.isEmpty()) {
                System.out.println(">>> Base de datos vacia: insertando objetos de prueba... <<<");
                em.getTransaction().begin();

                Date fechaActual = new Date();

                // 1. Usuario
                Usuario usuario = new Usuario("admin", "admin123", "Ignacio", "Generoso");
                em.persist(usuario);

                // 2. Punto de Venta
                PuntoVenta puntoVenta = new PuntoVenta(1, "Sucursal Central", "Electronica", "Av. San Martin 1234");
                puntoVenta.setFechaAlta(fechaActual);
                puntoVenta.setFechaModificacion(fechaActual);
                puntoVenta.setUsuarioCarga(usuario);
                puntoVenta.setUsuarioModificacion(usuario);
                em.persist(puntoVenta);

                // 3. Rubros
                Rubro rubroHardware = new Rubro("Hardware y Perifericos", 101);
                rubroHardware.setFechaAlta(fechaActual);
                rubroHardware.setFechaModificacion(fechaActual);
                rubroHardware.setUsuarioCarga(usuario);
                rubroHardware.setUsuarioModificacion(usuario);
                em.persist(rubroHardware);

                Rubro rubroElectronica = new Rubro("Electrónica", 102);
                rubroElectronica.setFechaAlta(fechaActual);
                rubroElectronica.setFechaModificacion(fechaActual);
                rubroElectronica.setUsuarioCarga(usuario);
                rubroElectronica.setUsuarioModificacion(usuario);
                em.persist(rubroElectronica);

                // 4. Marca
                Marca marcaLogitech = new Marca("Logitech", 202);
                marcaLogitech.setFechaAlta(fechaActual);
                marcaLogitech.setFechaModificacion(fechaActual);
                marcaLogitech.setUsuarioCarga(usuario);
                marcaLogitech.setUsuarioModificacion(usuario);
                em.persist(marcaLogitech);

                Marca marcaSony = new Marca("Sony", 203);
                marcaSony.setFechaAlta(fechaActual);
                marcaSony.setFechaModificacion(fechaActual);
                marcaSony.setUsuarioCarga(usuario);
                marcaSony.setUsuarioModificacion(usuario);
                em.persist(marcaSony);

                // 5. Articulos
                Articulo teclado = new Articulo(rubroHardware, "ART-001", "Teclado Mecanico RGB", marcaLogitech);
                teclado.setFechaAlta(fechaActual);
                teclado.setFechaModificacion(fechaActual);
                teclado.setUsuarioCarga(usuario);
                teclado.setUsuarioModificacion(usuario);
                em.persist(teclado);

                Articulo mouse = new Articulo(rubroHardware, "ART-002", "Mouse Inalambrico Pro", marcaLogitech);
                mouse.setFechaAlta(fechaActual);
                mouse.setFechaModificacion(fechaActual);
                mouse.setUsuarioCarga(usuario);
                mouse.setUsuarioModificacion(usuario);
                em.persist(mouse);

                Articulo auriculares = new Articulo(rubroElectronica, "ART-003", "Auriculares Inalambricos WH-1000",
                        marcaSony);
                auriculares.setFechaAlta(fechaActual);
                auriculares.setFechaModificacion(fechaActual);
                auriculares.setUsuarioCarga(usuario);
                auriculares.setUsuarioModificacion(usuario);
                em.persist(auriculares);

                // 6. Lista de Precios
                ListaPrecio listaMayorista = new ListaPrecio("LP-MAY", "Lista Mayorista General");
                listaMayorista.setFechaAlta(fechaActual);
                listaMayorista.setFechaModificacion(fechaActual);
                listaMayorista.setUsuarioCarga(usuario);
                listaMayorista.setUsuarioModificacion(usuario);
                em.persist(listaMayorista);

                ListaPrecioArticulo lpaTeclado = new ListaPrecioArticulo(listaMayorista, 75000.0, teclado);
                lpaTeclado.setFechaAlta(fechaActual);
                lpaTeclado.setFechaModificacion(fechaActual);
                lpaTeclado.setUsuarioCarga(usuario);
                lpaTeclado.setUsuarioModificacion(usuario);
                em.persist(lpaTeclado);

                ListaPrecioArticulo lpaMouse = new ListaPrecioArticulo(listaMayorista, 45000.0, mouse);
                lpaMouse.setFechaAlta(fechaActual);
                lpaMouse.setFechaModificacion(fechaActual);
                lpaMouse.setUsuarioCarga(usuario);
                lpaMouse.setUsuarioModificacion(usuario);
                em.persist(lpaMouse);

                ListaPrecioArticulo lpaAuriculares = new ListaPrecioArticulo(listaMayorista, 120000.0, auriculares);
                lpaAuriculares.setFechaAlta(fechaActual);
                lpaAuriculares.setFechaModificacion(fechaActual);
                lpaAuriculares.setUsuarioCarga(usuario);
                lpaAuriculares.setUsuarioModificacion(usuario);
                em.persist(lpaAuriculares);

                // 7. Contacto, Domicilio y Cliente
                Contacto contacto = new Contacto("cliente@empresa.com", "42345678", "1198765432");
                Domicilio domicilio = new Domicilio("Av. Corrientes", "1234");
                Cliente cliente = new Cliente("30-12345678-9", "Empresa Distribuidora SA", contacto, domicilio);
                cliente.setFechaAlta(fechaActual);
                cliente.setFechaModificacion(fechaActual);
                cliente.setUsuarioCarga(usuario);
                cliente.setUsuarioModificacion(usuario);
                em.persist(cliente);

                // 8. Condicion IVA y Moneda
                CondicionIva condicionIva = new CondicionIva(1, "Responsable Inscripto");
                condicionIva.setFechaAlta(fechaActual);
                condicionIva.setFechaModificacion(fechaActual);
                condicionIva.setUsuarioCarga(usuario);
                condicionIva.setUsuarioModificacion(usuario);
                em.persist(condicionIva);

                TipoMoneda tipoMoneda = new TipoMoneda("PES", "Pesos Argentinos", "$");
                tipoMoneda.setFechaAlta(fechaActual);
                tipoMoneda.setFechaModificacion(fechaActual);
                tipoMoneda.setUsuarioCarga(usuario);
                tipoMoneda.setUsuarioModificacion(usuario);
                em.persist(tipoMoneda);

                // 9. Factura de Venta con detalles en cascada
                FacturaVenta factura = new FacturaVenta();
                factura.setNumero(10001L);
                factura.setFechaEmision(fechaActual);
                factura.setPuntoVenta(puntoVenta);
                factura.setCliente(cliente);
                factura.setCondicionIva(condicionIva);
                factura.setTipoMoneda(tipoMoneda);
                factura.setEstado("EMITIDA");
                factura.setCae("74281928401923");
                factura.setCaeFechaVencimiento(fechaActual);
                factura.setResultadoAfip("APROBADA");
                factura.setObservaciones("Factura de venta mayorista con persistencia en cascada");
                factura.setFechaAlta(fechaActual);
                factura.setFechaModificacion(fechaActual);
                factura.setUsuarioCarga(usuario);
                factura.setUsuarioModificacion(usuario);

                FacturaVentaDetalle detalle1 = new FacturaVentaDetalle(
                        lpaTeclado,
                        "Teclado Mecanico RGB Switch Brown",
                        2.0,
                        75000.0,
                        0.0,
                        150000.0,
                        31500.0,
                        181500.0);

                FacturaVentaDetalle detalle2 = new FacturaVentaDetalle(
                        lpaMouse,
                        "Mouse Inalambrico Pro Sensor Hero",
                        4.0,
                        45000.0,
                        10.0,
                        162000.0,
                        34020.0,
                        196020.0);

                factura.addDetalle(detalle1);
                factura.addDetalle(detalle2);

                double total = detalle1.getImporteSubtotal() + detalle2.getImporteSubtotal();
                factura.setImporteTotal(total);
                factura.setImporteCobrado(total);
                factura.setImporteSaldo(0.0);

                em.persist(factura);

                em.getTransaction().commit();
                System.out.println(">>> Objetos de prueba guardados exitosamente en PostgreSQL <<<");
            } else {
                System.out.println(">>> La base de datos ya contiene datos (" + facturasExistentes.size()
                        + " facturas encontradas) <<<");
            }

            // Inicio TP JPQL

            // 1. Obtener la lista completa de todas las facturas de venta
            List<FacturaVenta> facturasCompletas = em.createQuery(
                    "SELECT f FROM FacturaVenta f", FacturaVenta.class)
                    .getResultList();
            for (FacturaVenta f : facturasCompletas) {
                System.out.println("Factura Nro: " + f.getNumero() + " | Fecha: " + f.getFechaEmision() + " | Total: $"
                        + f.getImporteTotal());
            }

            // 2. Proyección: número de factura, fecha de emisión e importe total
            List<Object[]> proyeccionFacturas = em.createQuery(
                    "SELECT f.numero, f.fechaEmision, f.importeTotal FROM FacturaVenta f", Object[].class)
                    .getResultList();
            for (Object[] fila : proyeccionFacturas) {
                System.out.println("Nro: " + fila[0] + " | Fecha: " + fila[1] + " | Total: $" + fila[2]);
            }

            // 3. Artículos que pertenecen al rubro con denominación específica (WHERE)
            List<Articulo> articulosRubro = em.createQuery(
                    "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :rubro", Articulo.class)
                    .setParameter("rubro", "Electrónica")
                    .getResultList();
            for (Articulo a : articulosRubro) {
                System.out.println("Código: " + a.getCodigo() + " | Denominación: " + a.getDenominacion());
            }

            // 4. Facturas emitidas dentro de un rango de fechas (BETWEEN)
            long unDiaMs = 24L * 60 * 60 * 1000;
            Date fechaInicio = new Date(System.currentTimeMillis() - (7 * unDiaMs));
            Date fechaFin = new Date(System.currentTimeMillis() + unDiaMs);
            List<FacturaVenta> facturasPorFecha = em.createQuery(
                    "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :inicio AND :fin", FacturaVenta.class)
                    .setParameter("inicio", fechaInicio)
                    .setParameter("fin", fechaFin)
                    .getResultList();
            for (FacturaVenta f : facturasPorFecha) {
                System.out.println("Factura Nro: " + f.getNumero() + " | Fecha: " + f.getFechaEmision() + " | Total: $"
                        + f.getImporteTotal());
            }

            // 5. Facturas con estado 'EMITIDA', importeTotal > 10000 y no anuladas
            List<FacturaVenta> facturasEmitidas = em.createQuery(
                    "SELECT f FROM FacturaVenta f " +
                            "WHERE f.estado = :estado " +
                            "AND f.importeTotal > :minImporte " +
                            "AND f.fechaAnulacion IS NULL",
                    FacturaVenta.class)
                    .setParameter("estado", "EMITIDA")
                    .setParameter("minImporte", 10000.0)
                    .getResultList();
            for (FacturaVenta f : facturasEmitidas) {
                System.out.println("Factura Nro: " + f.getNumero() + " | Total: $" + f.getImporteTotal() + " | Estado: "
                        + f.getEstado());
            }

            // 6. Búsqueda por patrón de texto (LIKE y LOWER) o CUIT empezando con 20-
            List<Cliente> clientesFiltrados = em.createQuery(
                    "SELECT c FROM Cliente c " +
                            "WHERE LOWER(c.denominacion) LIKE LOWER(:texto) " +
                            "OR c.cuitCuil LIKE :cuitInicio",
                    Cliente.class)
                    .setParameter("texto", "%distribuidora%")
                    .setParameter("cuitInicio", "20-%")
                    .getResultList();
            for (Cliente c : clientesFiltrados) {
                System.out.println("Cliente: " + c.getDenominacion() + " | CUIT: " + c.getCuitCuil());
            }

            // 7. Estados posibles sin duplicados ordenados alfabéticamente (DISTINCT y
            // ORDER BY)
            List<String> estadosDistintos = em.createQuery(
                    "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC", String.class)
                    .getResultList();
            for (String estado : estadosDistintos) {
                System.out.println("Estado: " + estado);
            }

            // 8. Cantidad de facturas, suma de importes y promedio (COUNT, SUM, AVG)
            Object[] agregaciones = em.createQuery(
                    "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) " +
                            "FROM FacturaVenta f WHERE f.estado = :estado",
                    Object[].class)
                    .setParameter("estado", "EMITIDA")
                    .getSingleResult();
            System.out.println("Cantidad: " + agregaciones[0] + " | Suma total: $" + agregaciones[1] + " | Promedio: $"
                    + agregaciones[2]);

            // 9. Puntos de venta cuyo número coincida con lista de parámetros (IN)
            List<PuntoVenta> puntosVentaIn = em.createQuery(
                    "SELECT pv FROM PuntoVenta pv WHERE pv.numero IN (:lista)", PuntoVenta.class)
                    .setParameter("lista", List.of(1, 2, 5))
                    .getResultList();
            for (PuntoVenta pv : puntosVentaIn) {
                System.out.println("Punto de Venta Nro: " + pv.getNumero() + " | " + pv.getDescripcion());
            }

            // 10. Facturas creadas por usuario de carga navegando por usuarioCarga.usuario
            List<FacturaVenta> facturasPorUsuario = em.createQuery(
                    "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :user", FacturaVenta.class)
                    .setParameter("user", "admin")
                    .getResultList();
            for (FacturaVenta f : facturasPorUsuario) {
                System.out.println(
                        "Factura Nro: " + f.getNumero() + " | Usuario de carga: " + f.getUsuarioCarga().getUsuario());
            }

            // 11. Detalles de factura de facturas emitidas por un punto de venta (INNER
            // JOIN)
            List<FacturaVentaDetalle> detallesPuntoVenta = em.createQuery(
                    "SELECT d FROM FacturaVentaDetalle d INNER JOIN d.factura f WHERE f.puntoVenta.numero = :ptoVta",
                    FacturaVentaDetalle.class)
                    .setParameter("ptoVta", 1)
                    .getResultList();
            for (FacturaVentaDetalle d : detallesPuntoVenta) {
                System.out.println("Detalle: " + d.getDescripcion() + " | Cantidad: " + d.getCantidad()
                        + " | Subtotal: $" + d.getImporteSubtotal());
            }

            // 12. Artículos con su marca, incluyendo artículos sin marca (LEFT JOIN)
            List<Object[]> articulosMarca = em.createQuery(
                    "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m", Object[].class)
                    .getResultList();
            for (Object[] fila : articulosMarca) {
                System.out.println("Artículo: " + fila[0] + " | Marca: " + (fila[1] != null ? fila[1] : "Sin Marca"));
            }

            // 13. Facturas que contengan artículos de una marca específica (JOINs
            // combinados)
            List<FacturaVenta> facturasMarca = em.createQuery(
                    "SELECT DISTINCT f FROM FacturaVenta f " +
                            "JOIN f.detalles d " +
                            "JOIN d.listaPrecioArticulo lpa " +
                            "JOIN lpa.articulo a " +
                            "WHERE a.marca.denominacion = :marca",
                    FacturaVenta.class)
                    .setParameter("marca", "Logitech")
                    .getResultList();
            for (FacturaVenta f : facturasMarca) {
                System.out.println("Factura Nro: " + f.getNumero() + " contiene artículos de la marca buscada");
            }

            // 14. Facturas con importe mayor al promedio general (Subconsulta en WHERE)
            List<FacturaVenta> facturasMayorPromedio = em.createQuery(
                    "SELECT f FROM FacturaVenta f " +
                            "WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2)",
                    FacturaVenta.class)
                    .getResultList();
            for (FacturaVenta f : facturasMayorPromedio) {
                System.out.println("Factura Nro: " + f.getNumero() + " | Importe: $" + f.getImporteTotal());
            }

            // 15. Punto de venta, cantidad de facturas y suma total facturada (GROUP BY)
            List<Object[]> resumenPtoVta = em.createQuery(
                    "SELECT pv.descripcion, COUNT(f), SUM(f.importeTotal) " +
                            "FROM FacturaVenta f JOIN f.puntoVenta pv " +
                            "GROUP BY pv.descripcion",
                    Object[].class)
                    .getResultList();
            for (Object[] fila : resumenPtoVta) {
                System.out.println(
                        "Punto de Venta: " + fila[0] + " | Cantidad: " + fila[1] + " | Total Facturado: $" + fila[2]);
            }

            // 16. Usuarios de carga con más de 5 facturas registradas (HAVING)
            List<Object[]> usuariosFacturas = em.createQuery(
                    "SELECT f.usuarioCarga.usuario, COUNT(f) " +
                            "FROM FacturaVenta f " +
                            "GROUP BY f.usuarioCarga.usuario " +
                            "HAVING COUNT(f) > :minimo",
                    Object[].class)
                    .setParameter("minimo", 0L)
                    .getResultList();
            for (Object[] fila : usuariosFacturas) {
                System.out.println("Usuario: " + fila[0] + " | Facturas registradas: " + fila[1]);
            }

            // 17. Unidades vendidas y subtotal acumulado por marca (GROUP BY con
            // relaciones)
            List<Object[]> agrupadoPorMarca = em.createQuery(
                    "SELECT a.marca.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) " +
                            "FROM FacturaVentaDetalle d " +
                            "JOIN d.listaPrecioArticulo lpa " +
                            "JOIN lpa.articulo a " +
                            "GROUP BY a.marca.denominacion",
                    Object[].class)
                    .getResultList();
            for (Object[] fila : agrupadoPorMarca) {
                System.out
                        .println("Marca: " + fila[0] + " | Unidades vendidas: " + fila[1] + " | Subtotal: $" + fila[2]);
            }

            // 18. Marcas que tienen al menos un artículo facturado (EXISTS)
            List<Marca> marcasConVentas = em.createQuery(
                    "SELECT m FROM Marca m WHERE EXISTS (" +
                            "  SELECT d FROM FacturaVentaDetalle d WHERE d.listaPrecioArticulo.articulo.marca = m" +
                            ")",
                    Marca.class)
                    .getResultList();
            for (Marca m : marcasConVentas) {
                System.out.println("Marca facturada: " + m.getDenominacion());
            }

            // 19. Artículos registrados que nunca fueron incluidos en una factura (NOT
            // EXISTS)
            List<Articulo> articulosNuncaFacturados = em.createQuery(
                    "SELECT a FROM Articulo a WHERE NOT EXISTS (" +
                            "  SELECT d FROM FacturaVentaDetalle d WHERE d.listaPrecioArticulo.articulo = a" +
                            ")",
                    Articulo.class)
                    .getResultList();
            for (Articulo a : articulosNuncaFacturados) {
                System.out.println("Artículo sin ventas: " + a.getDenominacion());
            }

            // 20. Clasificación de facturas según su importe (CASE WHEN) ordenadas de mayor
            // a menor
            List<Object[]> facturasConCategoria = em.createQuery(
                    "SELECT f.numero, f.importeTotal, " +
                            "CASE " +
                            "  WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' " +
                            "  WHEN f.importeTotal BETWEEN 10000 AND 50000 THEN 'MEDIO VALOR' " +
                            "  ELSE 'BAJO VALOR' " +
                            "END " +
                            "FROM FacturaVenta f ORDER BY f.importeTotal DESC",
                    Object[].class)
                    .getResultList();
            for (Object[] fila : facturasConCategoria) {
                System.out.println("Factura Nro: " + fila[0] + " | Total: $" + fila[1] + " | Categoría: " + fila[2]);
            }

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}