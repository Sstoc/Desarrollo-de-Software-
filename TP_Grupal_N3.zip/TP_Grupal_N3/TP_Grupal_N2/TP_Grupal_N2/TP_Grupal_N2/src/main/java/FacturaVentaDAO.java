import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.Date;
import java.util.List;

public class FacturaVentaDAO {

    private EntityManager em;

    public FacturaVentaDAO(EntityManager em) {
        this.em = em;
    }

    public List<FacturaVenta> obtenerFacturasPorRangoDeFechas(Date fechaInicio, Date fechaFin) {
        TypedQuery<FacturaVenta> query = em.createNamedQuery("rango.fechas", FacturaVenta.class);
        query.setParameter("fechaInicio", fechaInicio);
        query.setParameter("fechaFin", fechaFin);
        return query.getResultList();
    }
}